/*
 * Copyright 2024 HM Revenue & Customs
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package helpers

import models.EnrolmentRequest.AllocateEnrolmentParameters
import models.requests.SubscriptionDataRequest
import models.rfm.CorporatePosition
import models.subscription.*
import models.subscription.AccountStatus.ActiveAccount
import models.{MneOrDomestic, NonUKAddress, Verifier}
import play.api.i18n.Messages
import uk.gov.hmrc.govukfrontend.views.viewmodels.summarylist.SummaryList
import utils.countryOptions.CountryOptions
import viewmodels.checkAnswers.manageAccount.*
import viewmodels.govuk.summarylist.SummaryListViewModel

import java.time.LocalDate

trait SubscriptionLocalDataFixture {

  private val upeCorrespondenceAddress = UpeCorrespAddressDetails("middle", None, Some("lane"), None, None, "obv")
  private val upeDetailsAmend          =
    UpeDetailsAmend("plrReference", None, None, "orgName", LocalDate.of(2024, 1, 31), domesticOnly = false, filingMember = false)
  private val contactDetails = ContactDetailsType("shadow", Some("dota2"), "shadow@fiend.com")
  val filingMemberAmendDetails: FilingMemberAmendDetails = FilingMemberAmendDetails(
    addNewFilingMember = true,
    safeId = "someSafeId",
    customerIdentification1 = Some("CRN"),
    customerIdentification2 = Some("UTR"),
    organisationName = "Company"
  )

  val originalAccountingPeriod: OriginalAccountingPeriod =
    OriginalAccountingPeriod(
      taxObligationStartDate = LocalDate.of(2024, 1, 1),
      taxObligationEndDate = LocalDate.of(2024, 12, 31)
    )

  val newAccountingPeriod: NewAccountingPeriod =
    NewAccountingPeriod(
      updateObligationStartDate = LocalDate.of(2025, 1, 1),
      updateObligationEndDate = LocalDate.of(2025, 12, 31)
    )

  lazy val currentDate: LocalDate = LocalDate.of(2025, 7, 18)

  val emptySubscriptionLocalData: SubscriptionLocalData = SubscriptionLocalData(
    plrReference = "Abc123",
    subMneOrDomestic = MneOrDomestic.Uk,
    subAccountingPeriod = Some(AccountingPeriod(LocalDate.of(2025, 7, 18), LocalDate.of(2025, 7, 18).plusYears(1))),
    subPrimaryContactName = "",
    subPrimaryEmail = "",
    subPrimaryPhonePreference = false,
    subPrimaryCapturePhone = None,
    subAddSecondaryContact = false,
    subSecondaryContactName = None,
    subSecondaryEmail = None,
    subSecondaryCapturePhone = None,
    subSecondaryPhonePreference = Some(false),
    subRegisteredAddress = NonUKAddress("", None, "", None, None, ""),
    accountStatus = Some(AccountStatus.ActiveAccount),
    organisationName = None
  )

  val someSubscriptionLocalData: SubscriptionLocalData = SubscriptionLocalData(
    plrReference = "Abc123",
    subMneOrDomestic = MneOrDomestic.Uk,
    subAccountingPeriod = Some(AccountingPeriod(LocalDate.of(2025, 7, 18), LocalDate.of(2025, 7, 18).plusYears(1))),
    subPrimaryContactName = "John",
    subPrimaryEmail = "john@email.com",
    subPrimaryPhonePreference = true,
    subPrimaryCapturePhone = Some("123"),
    subAddSecondaryContact = true,
    subSecondaryContactName = Some("Doe"),
    subSecondaryEmail = Some("doe@email.com"),
    subSecondaryCapturePhone = Some("123"),
    subSecondaryPhonePreference = Some(true),
    subRegisteredAddress = NonUKAddress("line1", None, "line", None, None, "GB"),
    accountStatus = Some(ActiveAccount),
    organisationName = Some("ABC Intl")
  )

  val subscriptionData: SubscriptionDataV1 = SubscriptionDataV1(
    formBundleNumber = "form bundle",
    upeDetails = UpeDetails(None, None, None, "orgName", LocalDate.of(2024, 1, 31), domesticOnly = false, filingMember = false),
    upeCorrespAddressDetails = upeCorrespondenceAddress,
    primaryContactDetails = contactDetails,
    secondaryContactDetails = None,
    filingMemberDetails = None,
    accountingPeriod = AccountingPeriod(currentDate, currentDate.plusYears(1)),
    accountStatus = Some(ActiveAccount)
  )

  val subscriptionDataV2: SubscriptionDataV2 = SubscriptionDataV2(
    formBundleNumber = "form bundle",
    upeDetails = UpeDetails(None, None, None, "orgName", LocalDate.of(2024, 1, 31), domesticOnly = false, filingMember = false),
    upeCorrespAddressDetails = upeCorrespondenceAddress,
    primaryContactDetails = contactDetails,
    secondaryContactDetails = None,
    filingMemberDetails = None,
    accountingPeriod = Some(
      Seq(
        AccountingPeriodV2(
          startDate = None,
          endDate = None,
          dueDate = None,
          canAmendStartDate = Some(false),
          canAmendEndDate = Some(false)
        )
      )
    ),
    accountStatus = Some(ActiveAccount)
  )

  val allocateEnrolmentParameters: AllocateEnrolmentParameters = AllocateEnrolmentParameters(
    userId = "id",
    verifiers = Seq(Verifier("CTUTR", "Utr"), Verifier("CRN", "Crn"))
  )

  val accountingPeriodAmendV2: AccountingPeriodAmendV2 =
    AccountingPeriodAmendV2(
      amendAccountingPeriod = true,
      originalAccountingPeriods = Some(Seq(originalAccountingPeriod)),
      newAccountingPeriod = Some(newAccountingPeriod)
    )

  val amendSubscriptionDataV2: AmendSubscriptionV2 = AmendSubscriptionV2(
    replaceFilingMember = true,
    upeDetails = upeDetailsAmend,
    accountingPeriod = accountingPeriodAmendV2,
    upeCorrespAddressDetails = upeCorrespondenceAddress,
    primaryContactDetails = contactDetails,
    secondaryContactDetails = Some(contactDetails),
    filingMemberDetails = Some(filingMemberAmendDetails)
  )

  val replaceFilingMemberData: NewFilingMemberDetail = NewFilingMemberDetail(
    securityAnswerUserReference = "plrReference",
    securityAnswerRegistrationDate = LocalDate.of(2024, 12, 31),
    plrReference = "plrReference",
    corporatePosition = CorporatePosition.Upe,
    ukBased = Some(false),
    nameRegistration = Some("nameRegistration"),
    registeredAddress = Some(NonUKAddress("middle", None, "lane", None, None, "obv")),
    primaryContactName = "shadow",
    primaryContactEmail = "shadow@fiend.com",
    primaryContactPhonePreference = true,
    primaryContactPhoneNumber = Some("dota2"),
    addSecondaryContact = true,
    secondaryContactInformation = Some(contactDetails),
    contactAddress = NonUKAddress("middle", None, "lane", None, None, "obv")
  )

  def subscriptionDataGroupSummaryList()(using messages: Messages, request: SubscriptionDataRequest[?]): SummaryList = SummaryListViewModel(
    rows = Seq(
      MneOrDomesticSummary.row(),
      GroupAccountingPeriodSummary.row(),
      GroupAccountingPeriodStartDateSummary.row(),
      GroupAccountingPeriodEndDateSummary.row()
    ).flatten
  )

  def subscriptionDataPrimaryContactList()(using messages: Messages, request: SubscriptionDataRequest[?]): SummaryList = SummaryListViewModel(
    rows = Seq(
      ContactNameComplianceSummary.row(),
      ContactEmailAddressSummary.row(),
      ContactByPhoneSummary.row(),
      ContactCapturePhoneDetailsSummary.row()
    ).flatten
  )

  def subscriptionDataSecondaryContactList()(using messages: Messages, request: SubscriptionDataRequest[?]): SummaryList = SummaryListViewModel(
    rows = Seq(
      AddSecondaryContactSummary.row(),
      SecondaryContactNameSummary.row(),
      SecondaryContactEmailSummary.row(),
      SecondaryPhonePreferenceSummary.row(),
      SecondaryPhoneSummary.row()
    ).flatten
  )

  def subscriptionDataAddress(countryOptions: CountryOptions)(using
    messages: Messages,
    request:  SubscriptionDataRequest[?]
  ): SummaryList = SummaryListViewModel(
    rows = Seq(ContactCorrespondenceAddressSummary.row(countryOptions)).flatten
  )

  val someSubscriptionLocalDataUkOther: SubscriptionLocalData = SubscriptionLocalData(
    plrReference = "Abc123",
    subMneOrDomestic = MneOrDomestic.UkAndOther,
    subAccountingPeriod = Some(AccountingPeriod(LocalDate.of(2024, 10, 24), LocalDate.of(2025, 10, 23))),
    subPrimaryContactName = "John",
    subPrimaryEmail = "john@email.com",
    subPrimaryPhonePreference = true,
    subPrimaryCapturePhone = Some("123"),
    subAddSecondaryContact = true,
    subSecondaryContactName = Some("Doe"),
    subSecondaryEmail = Some("doe@email.com"),
    subSecondaryCapturePhone = Some("123"),
    subSecondaryPhonePreference = Some(true),
    subRegisteredAddress = NonUKAddress("line1", None, "line", None, None, "GB"),
    accountStatus = Some(ActiveAccount),
    organisationName = Some("orgName")
  )
}
