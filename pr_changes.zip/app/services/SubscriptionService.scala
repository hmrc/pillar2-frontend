/*
 * Copyright 2024 HM Revenue & Customs
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package services

import connectors.*
import models.*
import models.EnrolmentRequest.{AllocateEnrolmentParameters, KnownFacts, KnownFactsParameters}
import models.registration.*
import models.rfm.CorporatePosition
import models.subscription.*
import org.apache.pekko.Done
import pages.*
import play.api.Logging
import play.api.libs.json.Json
import play.api.mvc.Result
import play.api.mvc.Results.Redirect
import uk.gov.hmrc.http.HeaderCarrier
import utils.FutureConverter.toFuture

import java.time.LocalDate
import javax.inject.{Inject, Singleton}
import scala.concurrent.{ExecutionContext, Future}

@Singleton
class SubscriptionService @Inject() (
  registrationConnector:        RegistrationConnector,
  subscriptionConnector:        SubscriptionConnector,
  userAnswersConnectors:        UserAnswersConnectors,
  enrolmentConnector:           TaxEnrolmentConnector,
  enrolmentStoreProxyConnector: EnrolmentStoreProxyConnector,
  appConfig:                    config.FrontendAppConfig
)(using ec: ExecutionContext)
    extends Logging {

  def createSubscription(userAnswers: UserAnswers)(using hc: HeaderCarrier): Future[String] = {
    logger.info(s"createSubscription - userAnswers: - ${Json.toJson(userAnswers)}")
    for {
      upeSafeId     <- registerUpe(userAnswers)
      latestAnswers <- userAnswersConnectors.getUserAnswer(userAnswers.id)
      updatedAnswers = latestAnswers.getOrElse(userAnswers)
      nfmSafeId       <- registerNfm(updatedAnswers)
      _               <- if upeSafeId != nfmSafeId.getOrElse("") then Future.unit else Future.failed(DuplicateSafeIdError)
      plrRef          <- subscriptionConnector.subscribe(SubscriptionRequestParameters(userAnswers.id, upeSafeId, nfmSafeId))
      enrolmentExists <- enrolmentExists(plrRef)
      _               <- if !enrolmentExists then Future.unit else Future.failed(DuplicateSubmissionError)
      enrolmentInfo = updatedAnswers.createEnrolmentInfo(plrRef)
      _ <- enrolmentConnector.enrolAndActivate(enrolmentInfo)
    } yield plrRef
  }

  private def enrolmentExists(plrReference: String)(using hc: HeaderCarrier): Future[Boolean] =
    enrolmentStoreProxyConnector.getGroupIds(plrReference).map {
      case Some(_) => true
      case _       => false
    }

  def maybeReadSubscription(plrReference: String)(using hc: HeaderCarrier): Future[Option[SubscriptionData]] =
    if appConfig.amendMultipleAccountingPeriods then subscriptionConnector.readSubscriptionV2(plrReference)
    else subscriptionConnector.readSubscription(plrReference)

  def readSubscription(plrReference: String)(using hc: HeaderCarrier): Future[SubscriptionData] =
    maybeReadSubscription(plrReference).flatMap {
      case Some(subData) => Future.successful(subData)
      case None          => Future.failed(NoResultFound)
    }

  def cacheSubscription(parameters: ReadSubscriptionRequestParameters)(using hc: HeaderCarrier): Future[SubscriptionDataV1] =
    subscriptionConnector.cacheSubscription(parameters)

  def getSubscriptionCache(userId: String)(using hc: HeaderCarrier): Future[SubscriptionLocalData] =
    subscriptionConnector.getSubscriptionCache(userId).flatMap {
      case Some(readSubscriptionResponse) =>
        Future.successful(readSubscriptionResponse)
      case _ =>
        Future.failed(InternalIssueError)
    }

  /** Call Read Subscription V2, convert to SubscriptionLocalData, and save to user-cache, also does not overwrite phone related fields on flag
    * alternation.
    */
  def readSubscriptionV2AndSave(
    userId:       String,
    plrReference: String
  )(using hc: HeaderCarrier): Future[SubscriptionLocalData] =
    for {
      existingOpt <- subscriptionConnector.getSubscriptionCache(userId)
      v2          <- subscriptionConnector.readAndCacheSubscriptionV2(userId, plrReference)
      fresh  = subscriptionDataV2ToLocalData(plrReference, v2)
      merged = existingOpt match {
                 case Some(existing) =>
                   fresh.copy(
                     subPrimaryPhonePreference = existing.subPrimaryPhonePreference,
                     subPrimaryCapturePhone = existing.subPrimaryCapturePhone,
                     subSecondaryPhonePreference = existing.subSecondaryPhonePreference,
                     subSecondaryCapturePhone = existing.subSecondaryCapturePhone
                   )
                 case None => fresh
               }
      _ <- subscriptionConnector.save(userId, Json.toJson(merged))
    } yield merged

  private def subscriptionDataV2ToLocalData(plrReference: String, v2: SubscriptionDataV2): SubscriptionLocalData = {
    val address = v2.upeCorrespAddressDetails
    SubscriptionLocalData(
      plrReference = plrReference,
      subMneOrDomestic = if v2.upeDetails.domesticOnly then MneOrDomestic.Uk else MneOrDomestic.UkAndOther,
      subPrimaryContactName = v2.primaryContactDetails.name,
      subPrimaryEmail = v2.primaryContactDetails.emailAddress,
      subPrimaryPhonePreference = v2.primaryContactDetails.phone.isDefined,
      subPrimaryCapturePhone = v2.primaryContactDetails.phone,
      subAddSecondaryContact = v2.secondaryContactDetails.isDefined,
      subSecondaryContactName = v2.secondaryContactDetails.map(_.name),
      subSecondaryEmail = v2.secondaryContactDetails.map(_.emailAddress),
      subSecondaryCapturePhone = v2.secondaryContactDetails.flatMap(_.phone),
      subSecondaryPhonePreference = v2.secondaryContactDetails.map(_.phone.isDefined),
      subRegisteredAddress = NonUKAddress(
        address.addressLine1,
        address.addressLine2,
        address.addressLine3.getOrElse(""),
        address.addressLine4,
        address.postCode,
        address.countryCode
      ),
      accountStatus = v2.accountStatus,
      organisationName = Some(v2.upeDetails.organisationName),
      accountingPeriods = v2.accountingPeriod,
      registrationDate = Some(v2.upeDetails.registrationDate),
      upeCustomerIdentification1 = v2.upeDetails.customerIdentification1,
      upeCustomerIdentification2 = v2.upeDetails.customerIdentification2,
      upeFilingMember = Some(v2.upeDetails.filingMember),
      filingMemberDetails = v2.filingMemberDetails
    )
  }

  def matchingPillar2Records(id: String, sessionPillar2Id: String, sessionRegistrationDate: LocalDate)(using
    hc: HeaderCarrier
  ): Future[Boolean] =
    userAnswersConnectors.getUserAnswer(id).map { maybeUserAnswers =>
      (for {
        backendPillar2Id        <- maybeUserAnswers.flatMap(_.get(RfmPillar2ReferencePage))
        backendRegistrationDate <- maybeUserAnswers.flatMap(_.get(RfmRegistrationDatePage))
      } yield backendPillar2Id.equals(sessionPillar2Id) & backendRegistrationDate
        .isEqual(sessionRegistrationDate)).getOrElse(false)
    }

  def amendContactOrGroupDetails(userId: String, plrReference: String, subscriptionLocalData: SubscriptionLocalData)(using
    hc: HeaderCarrier
  ): Future[Done] =
    for {
      currentSubscriptionData <- readSubscription(plrReference)
      result                  <- currentSubscriptionData match {
                  case v1: SubscriptionDataV1 =>
                    subscriptionConnector.amendSubscription(userId, amendGroupOrContactDetails(plrReference, v1, subscriptionLocalData))
                  case v2: SubscriptionDataV2 =>
                    subscriptionConnector.amendSubscriptionV2(userId, amendGroupOrContactDetailsV2(plrReference, v2, subscriptionLocalData))
                }
    } yield result

  def amendAccountingPeriods(
    userId:          String,
    plrReference:    String,
    userData:        SubscriptionLocalData,
    affectedPeriods: Seq[AccountingPeriodV2],
    newPeriod:       AccountingPeriod
  )(using hc: HeaderCarrier): Future[Done] = {
    val amendData = buildAmendSubscriptionV2(plrReference, userData, affectedPeriods, newPeriod)
    subscriptionConnector.amendSubscriptionV2(userId, amendData)
  }

  private def buildAmendSubscriptionV2(
    plrReference:    String,
    userData:        SubscriptionLocalData,
    affectedPeriods: Seq[AccountingPeriodV2],
    newPeriod:       AccountingPeriod
  ): AmendSubscriptionV2 = {
    val address = UpeCorrespAddressDetails(
      addressLine1 = userData.subRegisteredAddress.addressLine1,
      addressLine2 = userData.subRegisteredAddress.addressLine2,
      addressLine3 = Some(userData.subRegisteredAddress.addressLine3),
      addressLine4 = userData.subRegisteredAddress.addressLine4,
      postCode = userData.subRegisteredAddress.postalCode,
      countryCode = userData.subRegisteredAddress.countryCode
    )
    AmendSubscriptionV2(
      replaceFilingMember = false,
      upeDetails = UpeDetailsAmend(
        plrReference,
        customerIdentification1 = userData.upeCustomerIdentification1,
        customerIdentification2 = userData.upeCustomerIdentification2,
        organisationName = userData.organisationName.getOrElse(""),
        registrationDate = userData.registrationDate.getOrElse(LocalDate.now()),
        domesticOnly = if userData.subMneOrDomestic == MneOrDomestic.Uk then true else false,
        filingMember = userData.upeFilingMember.getOrElse(false)
      ),
      accountingPeriod = AccountingPeriodAmendV2(
        amendAccountingPeriod = true,
        originalAccountingPeriods =
          Some(affectedPeriods.map(p => OriginalAccountingPeriod(p.startDate.getOrElse(LocalDate.now), p.endDate.getOrElse(LocalDate.now)))),
        newAccountingPeriod = Some(NewAccountingPeriod(newPeriod.startDate, newPeriod.endDate))
      ),
      upeCorrespAddressDetails = address,
      primaryContactDetails = ContactDetailsType(
        name = userData.subPrimaryContactName,
        phone = userData.subPrimaryCapturePhone,
        emailAddress = userData.subPrimaryEmail
      ),
      secondaryContactDetails = if userData.subAddSecondaryContact then {
        for {
          name  <- userData.subSecondaryContactName
          email <- userData.subSecondaryEmail
        } yield ContactDetailsType(name = name, phone = userData.subSecondaryCapturePhone, emailAddress = email)
      } else {
        None
      },
      filingMemberDetails = userData.filingMemberDetails.map(details =>
        FilingMemberAmendDetails(
          safeId = details.safeId,
          customerIdentification1 = details.customerIdentification1,
          customerIdentification2 = details.customerIdentification2,
          organisationName = details.organisationName
        )
      )
    )
  }

  private def registerUpe(userAnswers: UserAnswers)(using hc: HeaderCarrier): Future[String] =
    userAnswers.getUpeSafeID
      .map(Future.successful)
      .getOrElse {
        for {
          safeId         <- registrationConnector.registerUltimateParent(userAnswers.id)
          updatedAnswers <- Future.fromTry(userAnswers.set(UpeNonUKSafeIDPage, safeId))
          _              <- userAnswersConnectors.save(updatedAnswers.id, Json.toJson(updatedAnswers.data))
        } yield safeId
      }

  private def registerNfm(userAnswers: UserAnswers)(using hc: HeaderCarrier): Future[Option[String]] =
    userAnswers.getFmSafeID
      .map(safeId => Future.successful(Some(safeId)))
      .getOrElse {
        if userAnswers.get(NominateFilingMemberPage).contains(true) then {
          for {
            safeId         <- registrationConnector.registerFilingMember(userAnswers.id)
            updatedAnswers <- Future.fromTry(userAnswers.set(FmNonUKSafeIDPage, safeId))
            _              <- userAnswersConnectors.save(updatedAnswers.id, Json.toJson(updatedAnswers.data))
          } yield Some(safeId)
        } else {
          Future.successful(None)
        }
      }

  private[services] def amendGroupOrContactDetails(
    plrReference: String,
    currentData:  SubscriptionDataV1,
    userData:     SubscriptionLocalData
  ): AmendSubscription =
    AmendSubscription(
      replaceFilingMember = false,
      upeDetails = UpeDetailsAmend(
        plrReference,
        customerIdentification1 = currentData.upeDetails.customerIdentification1,
        customerIdentification2 = currentData.upeDetails.customerIdentification2,
        organisationName = currentData.upeDetails.organisationName,
        registrationDate = currentData.upeDetails.registrationDate,
        domesticOnly = if userData.subMneOrDomestic == MneOrDomestic.Uk then true else false,
        filingMember = currentData.upeDetails.filingMember
      ),
      accountingPeriod = {
        val period = userData.subAccountingPeriod.getOrElse(currentData.accountingPeriod)
        AccountingPeriodAmend(startDate = period.startDate, endDate = period.endDate)
      },
      upeCorrespAddressDetails = UpeCorrespAddressDetails(
        addressLine1 = userData.subRegisteredAddress.addressLine1,
        addressLine2 = userData.subRegisteredAddress.addressLine2,
        addressLine3 = Some(userData.subRegisteredAddress.addressLine3),
        addressLine4 = userData.subRegisteredAddress.addressLine4,
        postCode = userData.subRegisteredAddress.postalCode,
        countryCode = userData.subRegisteredAddress.countryCode
      ),
      primaryContactDetails = ContactDetailsType(
        name = userData.subPrimaryContactName,
        phone = userData.subPrimaryCapturePhone,
        emailAddress = userData.subPrimaryEmail
      ),
      secondaryContactDetails = if userData.subAddSecondaryContact then {
        for {
          name  <- userData.subSecondaryContactName
          email <- userData.subSecondaryEmail
        } yield ContactDetailsType(name = name, phone = userData.subSecondaryCapturePhone, emailAddress = email)
      } else {
        None
      },
      filingMemberDetails = currentData.filingMemberDetails.map(details =>
        FilingMemberAmendDetails(
          safeId = details.safeId,
          customerIdentification1 = details.customerIdentification1,
          customerIdentification2 = details.customerIdentification2,
          organisationName = details.organisationName
        )
      )
    )

  private[services] def amendGroupOrContactDetailsV2(
    plrReference: String,
    currentData:  SubscriptionData,
    userData:     SubscriptionLocalData
  ): AmendSubscriptionV2 =
    AmendSubscriptionV2(
      replaceFilingMember = false,
      upeDetails = UpeDetailsAmend(
        plrReference,
        customerIdentification1 = currentData.upeDetails.customerIdentification1,
        customerIdentification2 = currentData.upeDetails.customerIdentification2,
        organisationName = currentData.upeDetails.organisationName,
        registrationDate = currentData.upeDetails.registrationDate,
        domesticOnly = userData.subMneOrDomestic == MneOrDomestic.Uk,
        filingMember = currentData.upeDetails.filingMember
      ),
      accountingPeriod = AccountingPeriodAmendV2(
        amendAccountingPeriod = false,
        originalAccountingPeriods = None,
        newAccountingPeriod = None
      ),
      upeCorrespAddressDetails = UpeCorrespAddressDetails(
        addressLine1 = userData.subRegisteredAddress.addressLine1,
        addressLine2 = userData.subRegisteredAddress.addressLine2,
        addressLine3 = Some(userData.subRegisteredAddress.addressLine3),
        addressLine4 = userData.subRegisteredAddress.addressLine4,
        postCode = userData.subRegisteredAddress.postalCode,
        countryCode = userData.subRegisteredAddress.countryCode
      ),
      primaryContactDetails = ContactDetailsType(
        name = userData.subPrimaryContactName,
        phone = userData.subPrimaryCapturePhone,
        emailAddress = userData.subPrimaryEmail
      ),
      secondaryContactDetails =
        if userData.subAddSecondaryContact then
          for {
            name  <- userData.subSecondaryContactName
            email <- userData.subSecondaryEmail
          } yield ContactDetailsType(name, userData.subSecondaryCapturePhone, email)
        else None,
      filingMemberDetails = currentData.filingMemberDetails.map(details =>
        FilingMemberAmendDetails(
          safeId = details.safeId,
          customerIdentification1 = details.customerIdentification1,
          customerIdentification2 = details.customerIdentification2,
          organisationName = details.organisationName
        )
      )
    )

  private def setUltimateParentAsNewFilingMember(
    requiredInfo:     NewFilingMemberDetail,
    subscriptionData: SubscriptionData
  ): AmendSubscriptionV2 =
    AmendSubscriptionV2(
      replaceFilingMember = true,
      upeDetails = UpeDetailsAmend(
        plrReference = requiredInfo.plrReference,
        customerIdentification1 = subscriptionData.upeDetails.customerIdentification1,
        customerIdentification2 = subscriptionData.upeDetails.customerIdentification2,
        organisationName = subscriptionData.upeDetails.organisationName,
        registrationDate = subscriptionData.upeDetails.registrationDate,
        domesticOnly = subscriptionData.upeDetails.domesticOnly,
        filingMember = true
      ),
      accountingPeriod = AccountingPeriodAmendV2(amendAccountingPeriod = false, originalAccountingPeriods = None, newAccountingPeriod = None),
      upeCorrespAddressDetails = UpeCorrespAddressDetails(
        requiredInfo.contactAddress.addressLine1,
        requiredInfo.contactAddress.addressLine2,
        Some(requiredInfo.contactAddress.addressLine3),
        requiredInfo.contactAddress.addressLine4,
        requiredInfo.contactAddress.postalCode,
        requiredInfo.contactAddress.countryCode
      ),
      primaryContactDetails = ContactDetailsType(
        name = requiredInfo.primaryContactName,
        phone = requiredInfo.primaryContactPhoneNumber,
        emailAddress = requiredInfo.primaryContactEmail
      ),
      secondaryContactDetails = requiredInfo.secondaryContactInformation,
      filingMemberDetails = None
    )

  private def replaceOldFilingMember(
    requiredInfo:     NewFilingMemberDetail,
    subscriptionData: SubscriptionData,
    filingMember:     FilingMemberAmendDetails
  ): AmendSubscriptionV2 =
    AmendSubscriptionV2(
      replaceFilingMember = true,
      upeDetails = UpeDetailsAmend(
        plrReference = requiredInfo.plrReference,
        customerIdentification1 = subscriptionData.upeDetails.customerIdentification1,
        customerIdentification2 = subscriptionData.upeDetails.customerIdentification2,
        organisationName = subscriptionData.upeDetails.organisationName,
        registrationDate = subscriptionData.upeDetails.registrationDate,
        domesticOnly = subscriptionData.upeDetails.domesticOnly,
        filingMember = false
      ),
      accountingPeriod = AccountingPeriodAmendV2(amendAccountingPeriod = false, originalAccountingPeriods = None, newAccountingPeriod = None),
      upeCorrespAddressDetails = UpeCorrespAddressDetails(
        requiredInfo.contactAddress.addressLine1,
        requiredInfo.contactAddress.addressLine2,
        Some(requiredInfo.contactAddress.addressLine3),
        requiredInfo.contactAddress.addressLine4,
        requiredInfo.contactAddress.postalCode,
        requiredInfo.contactAddress.countryCode
      ),
      primaryContactDetails = ContactDetailsType(
        name = requiredInfo.primaryContactName,
        phone = requiredInfo.primaryContactPhoneNumber,
        emailAddress = requiredInfo.primaryContactEmail
      ),
      secondaryContactDetails = requiredInfo.secondaryContactInformation,
      filingMemberDetails = Some(filingMember)
    )

  def amendFilingMemberDetails(userId: String, amendData: AmendSubscriptionV2)(using hc: HeaderCarrier): Future[Done] =
    subscriptionConnector.amendSubscriptionV2(userId, amendData)

  private def registerOrGetNewFilingMemberSafeId(userAnswers: UserAnswers)(using hc: HeaderCarrier): Future[String] =
    for {
      safeID         <- userAnswers.get(RfmSafeIdPage).map(Future.successful).getOrElse(registrationConnector.registerNewFilingMember(userAnswers.id))
      updatedAnswers <- Future.fromTry(userAnswers.set(RfmSafeIdPage, safeID))
      _              <- userAnswersConnectors.save(updatedAnswers.id, Json.toJson(updatedAnswers.data))
    } yield safeID

  def deallocateEnrolment(plrReference: String)(using hc: HeaderCarrier): Future[Done] =
    enrolmentStoreProxyConnector.getGroupIds(plrReference).flatMap {
      case Some(groupIds) =>
        logger.info(s"deallocateEnrolment groupIds: - $groupIds")
        enrolmentConnector.revokeEnrolment(groupId = groupIds.principalGroupIds.head, plrReference = plrReference)
      case error =>
        logger.warn(s"deallocateEnrolment error: - $error")
        Future.failed(InternalIssueError)
    }

  def allocateEnrolment(groupId: String, plrReference: String, enrolmentInfo: AllocateEnrolmentParameters)(using hc: HeaderCarrier): Future[Done] =
    enrolmentConnector.allocateEnrolment(groupId, plrReference, enrolmentInfo)

  def getUltimateParentEnrolmentInformation(subscriptionData: SubscriptionData, pillar2Reference: String, userId: String)(using
    hc: HeaderCarrier
  ): Future[AllocateEnrolmentParameters] =
    subscriptionData.upeDetails.customerIdentification1
      .flatMap { crn =>
        logger.info(s"getUltimateParentEnrolmentInformation crn: - $crn")
        subscriptionData.upeDetails.customerIdentification2
          .map { utr =>
            logger.info(s"getUltimateParentEnrolmentInformation utr: - $utr")
            val enrolmentParameter =
              AllocateEnrolmentParameters(userId = userId, verifiers = Seq(Verifier(UTR.toString, utr), Verifier(CRN.toString, crn)))
            logger.info(s"getUltimateParentEnrolmentInformation WithId enrolment parameter - ${Json.toJson(enrolmentParameter)}")
            enrolmentParameter
          }
          .map(Future.successful)
      }
      .getOrElse(
        enrolmentStoreProxyConnector
          .getKnownFacts(KnownFactsParameters(knownFacts = Seq(KnownFacts(Pillar2Identifier.toString, pillar2Reference))))
          .map { knownFacts =>
            logger.info(s"getUltimateParentEnrolmentInformation knownFacts: - $knownFacts")
            val enrolmentParameter = AllocateEnrolmentParameters(userId = userId, verifiers = knownFacts.enrolments.flatMap(_.verifiers))
            logger.info(s"getUltimateParentEnrolmentInformation WithoutId enrolment parameter - ${Json.toJson(enrolmentParameter)}")
            enrolmentParameter

          }
      )

  private def getNewFilingMemberDetails(userAnswers: UserAnswers)(using hc: HeaderCarrier): Future[FilingMemberAmendDetails] =
    userAnswers
      .get(RfmUkBasedPage)
      .flatMap(ukBased =>
        if ukBased then {
          userAnswers
            .get(RfmGrsDataPage)
            .map(grsData =>
              FilingMemberAmendDetails(
                addNewFilingMember = true,
                safeId = grsData.companyId,
                customerIdentification1 = Some(grsData.crn),
                customerIdentification2 = Some(grsData.utr),
                organisationName = grsData.companyName
              ).toFuture
            )
        } else {
          userAnswers
            .get(RfmNameRegistrationPage)
            .map(companyName =>
              registerOrGetNewFilingMemberSafeId(userAnswers).map(companyId =>
                FilingMemberAmendDetails(
                  addNewFilingMember = true,
                  safeId = companyId,
                  customerIdentification1 = None,
                  customerIdentification2 = None,
                  organisationName = companyName
                )
              )
            )
        }
      )
      .getOrElse(throw new Exception("New Filing member details expected but could not find a value for RfmUkBased page"))

  def createAmendObjectForReplacingFilingMember(
    subscriptionData:   SubscriptionData,
    filingMemberDetail: NewFilingMemberDetail,
    userAnswers:        UserAnswers
  )(using hc: HeaderCarrier): Future[AmendSubscriptionV2] =
    if filingMemberDetail.corporatePosition == CorporatePosition.Upe then {
      logger.info("createAmendObjectForReplacingFilingMember - call setUltimateParentAsNewFilingMember")
      setUltimateParentAsNewFilingMember(requiredInfo = filingMemberDetail, subscriptionData = subscriptionData).toFuture
    } else {
      logger.info("createAmendObjectForReplacingFilingMember - call replaceOldFilingMember")
      getNewFilingMemberDetails(userAnswers).map(newFilingMember =>
        replaceOldFilingMember(
          requiredInfo = filingMemberDetail,
          subscriptionData = subscriptionData,
          filingMember = newFilingMember
        )
      )
    }

  def getCompanyNameFromGRS(grsResponse: GrsResponse): Option[String] =
    grsResponse.partnershipEntityRegistrationData
      .flatMap(_.companyProfile.map(_.companyName))
      .orElse(grsResponse.incorporatedEntityRegistrationData.map(_.companyProfile.companyName))

  def getCompanyName(userAnswers: UserAnswers): Either[Result, String] =
    userAnswers
      .get(FmNameRegistrationPage)
      .orElse(userAnswers.get(FmGRSResponsePage).flatMap(getCompanyNameFromGRS))
      .orElse(userAnswers.get(UpeNameRegistrationPage))
      .orElse(userAnswers.get(UpeGRSResponsePage).flatMap(getCompanyNameFromGRS)) match {
      case Some(companyName) => Right(companyName)
      case None              => Left(Redirect(controllers.routes.JourneyRecoveryController.onPageLoad()))
    }

}
