/*
 * Copyright 2026 HM Revenue & Customs
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package models

import models.subscription.AccountingPeriod

import java.time.LocalDate

final case class OutstandingPaymentsTable(accountingPeriod: AccountingPeriod, rows: Seq[OutstandingPaymentsRow])

final case class OutstandingPaymentsRow(description: String, outstandingAmount: BigDecimal, dueDate: LocalDate)

final case class OutstandingPaymentsTableForActivity(accountingPeriod: AccountingPeriod, rows: Seq[OutstandingPaymentsRowForActivity])

final case class OutstandingPaymentsRowForActivity(
  description:       String,
  chargeAmount:      BigDecimal,
  outstandingAmount: BigDecimal,
  dueDate:           LocalDate,
  appealFlag:        Option[Boolean]
)

case class OutstandingPaymentSummary(accountingPeriod: AccountingPeriod, items: Seq[OutstandingPaymentsRowForActivity])
