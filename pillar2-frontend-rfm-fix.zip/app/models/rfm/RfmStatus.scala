/*
 * Copyright 2024 HM Revenue & Customs
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package models.rfm

import models.{Enumerable, WithName}

sealed trait RfmStatus

object RfmStatus extends Enumerable.Implicits {

  case object SuccessfullyCompleted extends WithName("successfullyCompleted") with RfmStatus
  case object FailedInternalIssueError extends WithName("failedInternalIssueError") with RfmStatus
  case object FailException extends WithName("failException") with RfmStatus
  case object InProgress extends WithName("inProgress") with RfmStatus

  val values: Seq[RfmStatus] = Seq(
    SuccessfullyCompleted,
    FailedInternalIssueError,
    FailException,
    InProgress
  )

  given enumerable: Enumerable[RfmStatus] =
    Enumerable(values.map(v => v.toString -> v)*)

}
