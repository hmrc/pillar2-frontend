/*
 * Copyright 2026 HM Revenue & Customs
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package models.subscription

import play.api.libs.json.{Json, OFormat}

import java.time.LocalDate

final case class AccountingPeriodV2(
  startDate:         Option[LocalDate] = None,
  endDate:           Option[LocalDate] = None,
  dueDate:           Option[LocalDate] = None,
  canAmendStartDate: Option[Boolean] = Some(false),
  canAmendEndDate:   Option[Boolean] = Some(false)
) {

  def toAccountingPeriod: AccountingPeriod =
    AccountingPeriod(startDate = startDate.getOrElse(LocalDate.now), endDate = endDate.getOrElse(LocalDate.now), dueDate = dueDate)
}

object AccountingPeriodV2 {
  given format: OFormat[AccountingPeriodV2] = Json.format[AccountingPeriodV2]
}
