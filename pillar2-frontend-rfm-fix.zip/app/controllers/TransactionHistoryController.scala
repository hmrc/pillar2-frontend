/*
 * Copyright 2024 HM Revenue & Customs
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package controllers

import cats.data.OptionT
import config.FrontendAppConfig
import connectors.{AccountActivityConnector, FinancialDataConnector}
import controllers.TransactionHistoryController.{generatePagination, generateTransactionHistoryTable}
import controllers.actions.{DataRetrievalAction, IdentifierAction}
import models.*
import pages.AgentClientPillar2ReferencePage
import play.api.Logging
import play.api.i18n.{I18nSupport, Messages}
import play.api.mvc.*
import repositories.SessionRepository
import services.{ReferenceNumberService, SubscriptionService}
import uk.gov.hmrc.govukfrontend.views.Aliases.Text
import uk.gov.hmrc.govukfrontend.views.viewmodels.pagination.{Pagination, PaginationItem, PaginationLink}
import uk.gov.hmrc.govukfrontend.views.viewmodels.table.{HeadCell, Table, TableRow}
import uk.gov.hmrc.http.HeaderCarrier
import uk.gov.hmrc.play.bootstrap.frontend.controller.FrontendBaseController
import utils.DateTimeUtils.*
import views.ViewUtils.formatCurrencyAmount
import views.html.paymenthistory.{NoTransactionHistoryView, TransactionHistoryErrorView, TransactionHistoryView}

import java.time.LocalDate
import javax.inject.{Inject, Named}
import scala.concurrent.{ExecutionContext, Future}

class TransactionHistoryController @Inject() (
  val financialDataConnector:                     FinancialDataConnector,
  val accountActivityConnector:                   AccountActivityConnector,
  @Named("EnrolmentIdentifier") identifierAction: IdentifierAction,
  dataRetrievalAction:                            DataRetrievalAction,
  val controllerComponents:                       MessagesControllerComponents,
  referenceNumberService:                         ReferenceNumberService,
  subscriptionService:                            SubscriptionService,
  sessionRepository:                              SessionRepository,
  transactionHistoryView:                         TransactionHistoryView,
  noTransactionHistoryView:                       NoTransactionHistoryView,
  transactionHistoryErrorView:                    TransactionHistoryErrorView
)(using ec: ExecutionContext, appConfig: FrontendAppConfig)
    extends FrontendBaseController
    with I18nSupport
    with Logging {

  private def retrieveTransactionsAndUnallocatedAmount(plrReference: String, fromDate: LocalDate, toDate: LocalDate)(using
    hc: HeaderCarrier
  ): Future[(Seq[Transaction], BigDecimal)] =
    if appConfig.useAccountActivityApi then
      accountActivityConnector
        .retrieveAccountActivity(plrReference, fromDate, toDate)
        .map(response => (response.toTransactions, response.unallocatedPaymentAmount))
    else
      financialDataConnector
        .retrieveTransactionHistory(plrReference, fromDate, toDate)
        .map(response => (response.financialHistory, BigDecimal(0)))

  def onPageLoadTransactionHistory(page: Option[Int]): Action[AnyContent] =
    (identifierAction andThen dataRetrievalAction).async { request =>
      given Request[AnyContent] = request
      val result: OptionT[Future, Result] = for {
        mayBeUserAnswer <- OptionT.liftF(sessionRepository.get(request.userId))
        userAnswers = mayBeUserAnswer.getOrElse(UserAnswers(request.userId))
        referenceNumber <- OptionT
                             .fromOption[Future](userAnswers.get(AgentClientPillar2ReferencePage))
                             .orElse(OptionT.fromOption[Future](referenceNumberService.get(Some(userAnswers), request.enrolments)))
        subscriptionData <- OptionT.liftF(subscriptionService.readSubscription(referenceNumber))
        orgName = subscriptionData.upeDetails.organisationName
        transactionsAndUnallocatedPaymentAmount <-
          OptionT.liftF(
            retrieveTransactionsAndUnallocatedAmount(
              referenceNumber,
              subscriptionData.upeDetails.registrationDate,
              appConfig.transactionHistoryEndDate
            )
          )
        (financialHistory, unallocatedPaymentAmount) = transactionsAndUnallocatedPaymentAmount
        result <-
          if financialHistory.isEmpty then {
            OptionT.liftF(
              Future.successful(
                Ok(noTransactionHistoryView(orgName, referenceNumber, unallocatedPaymentAmount, appConfig.useAccountActivityApi, request.isAgent))
              )
            )
          } else
            OptionT
              .fromOption[Future](generateTransactionHistoryTable(page.getOrElse(1), financialHistory, appConfig.useAccountActivityApi))
              .map { table =>
                val pagination = generatePagination(financialHistory, page)
                Ok(
                  transactionHistoryView(
                    orgName,
                    referenceNumber,
                    unallocatedPaymentAmount,
                    appConfig.useAccountActivityApi,
                    table,
                    pagination,
                    request.isAgent
                  )
                )
              }
      } yield result

      result
        .getOrElse(Redirect(routes.TransactionHistoryController.onPageLoadError()))
        .recover {
          case NoResultFound      => Redirect(routes.TransactionHistoryController.onPageLoadNoTransactionHistory())
          case UnexpectedResponse => Redirect(routes.TransactionHistoryController.onPageLoadError())
        }
    }

  def onPageLoadNoTransactionHistory(): Action[AnyContent] =
    (identifierAction andThen dataRetrievalAction).async { request =>
      given Request[AnyContent] = request
      val result                = for {
        mayBeUserAnswer <- OptionT.liftF(sessionRepository.get(request.userId))
        userAnswers = mayBeUserAnswer.getOrElse(UserAnswers(request.userId))
        referenceNumber <- OptionT
                             .fromOption[Future](userAnswers.get(AgentClientPillar2ReferencePage))
                             .orElse(OptionT.fromOption[Future](referenceNumberService.get(Some(userAnswers), request.enrolments)))
        orgName <- OptionT.liftF(subscriptionService.readSubscription(referenceNumber).map(_.upeDetails.organisationName))
      } yield Ok(noTransactionHistoryView(orgName, referenceNumber, BigDecimal(0), appConfig.useAccountActivityApi, request.isAgent))

      result.getOrElse(Redirect(routes.TransactionHistoryController.onPageLoadError())).recover { case _ =>
        Redirect(routes.TransactionHistoryController.onPageLoadError())
      }
    }

  def onPageLoadError(): Action[AnyContent] = Action.async { request =>
    given Request[AnyContent] = request
    Future.successful(Ok(transactionHistoryErrorView()))
  }
}

object TransactionHistoryController {
  private val ROWS_ON_PAGE: Int = 10

  private[controllers] def generatePagination(transactions: Seq[Transaction], page: Option[Int])(using
    messages: Messages
  ): Option[Pagination] = {
    val paginationIndex = page.getOrElse(1)
    val numberOfPages   = transactions.grouped(ROWS_ON_PAGE).size

    if numberOfPages < 2 then { None }
    else {
      Some(
        Pagination(
          items = Some(generatePaginationItems(paginationIndex, numberOfPages)),
          previous = generatePreviousLink(paginationIndex),
          next = generateNextLink(paginationIndex, numberOfPages),
          landmarkLabel = None,
          attributes = Map.empty
        )
      )
    }
  }

  private def generatePaginationItems(paginationIndex: Int, numberOfPages: Int): Seq[PaginationItem] =
    Range
      .inclusive(1, numberOfPages)
      .map(pageIndex =>
        PaginationItem(
          href = routes.TransactionHistoryController.onPageLoadTransactionHistory(Some(pageIndex)).url,
          number = Some(pageIndex.toString),
          visuallyHiddenText = None,
          current = Some(pageIndex == paginationIndex),
          ellipsis = None,
          attributes = Map.empty
        )
      )

  private def generatePreviousLink(paginationIndex: Int)(using messages: Messages): Option[PaginationLink] =
    if paginationIndex == 1 then { None }
    else {
      Some(
        PaginationLink(
          href = routes.TransactionHistoryController.onPageLoadTransactionHistory(Some(paginationIndex - 1)).url,
          text = Some(messages("transactionHistory.pagination.previous")),
          labelText = None,
          attributes = Map.empty
        )
      )
    }

  private def generateNextLink(paginationIndex: Int, numberOfPages: Int)(using messages: Messages): Option[PaginationLink] =
    if paginationIndex == numberOfPages then { None }
    else {
      Some(
        PaginationLink(
          href = routes.TransactionHistoryController.onPageLoadTransactionHistory(Some(paginationIndex + 1)).url,
          text = Some(messages("transactionHistory.pagination.next")),
          labelText = None,
          attributes = Map.empty
        )
      )
    }

  private[controllers] def generateTransactionHistoryTable(paginationIndex: Int, transactions: Seq[Transaction], useNewApi: Boolean)(using
    messages: Messages
  ): Option[Table] = {
    val currentPage: Option[Seq[Transaction]] = transactions.grouped(ROWS_ON_PAGE).toSeq.lift(paginationIndex - 1)

    currentPage.map { historyOnPage =>
      val rows = historyOnPage.map(createTableRows(_, useNewApi))
      createTable(rows)
    }
  }

  private def createTable(rows: Seq[Seq[TableRow]])(using messages: Messages): Table =
    Table(
      rows = rows,
      head = Some(
        Seq(
          HeadCell(Text(messages("transactionHistory.date"))),
          HeadCell(Text(messages("transactionHistory.description"))),
          HeadCell(Text(messages("transactionHistory.amountPaid")), classes = "govuk-table__header--numeric"),
          HeadCell(Text(messages("transactionHistory.amountRepaid")), classes = "govuk-table__header--numeric")
        )
      ),
      firstCellIsHeader = true,
      caption = Some(messages("transactionHistory.transactions")),
      captionClasses = "govuk-table__caption--m"
    )

  private def createTableRows(history: Transaction, useNewApi: Boolean)(using messages: Messages): Seq[TableRow] = {
    val amountPaid:   String = formatCurrencyAmount(history.amountPaid)
    val amountRepaid: String = formatCurrencyAmount(history.amountRepaid)

    // New API uses message keys (payment, repayment, repaymentInterest); legacy API uses display strings
    val paymentTypeText =
      if useNewApi then
        history.paymentType match {
          case "repayment" | "repaymentInterest" => messages(s"transactionHistory.paymentType.${history.paymentType}")
          case other                             => other
        }
      else history.paymentType

    Seq(
      TableRow(
        content = Text(history.date.toDateFormat)
      ),
      TableRow(
        content = Text(paymentTypeText)
      ),
      TableRow(
        content = Text(amountPaid),
        classes = "govuk-table__cell--numeric"
      ),
      TableRow(
        content = Text(amountRepaid),
        classes = "govuk-table__cell--numeric"
      )
    )
  }
}
