/*
 * Copyright 2024 HM Revenue & Customs
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package controllers

import config.FrontendAppConfig
import controllers.actions.IdentifierAction
import models.UnprocessableEntityError
import play.api.Logging
import play.api.i18n.I18nSupport
import play.api.mvc.*
import play.twirl.api.Html
import services.SubscriptionService
import uk.gov.hmrc.play.bootstrap.frontend.controller.FrontendBaseController
import views.html.RegistrationInProgressView

import javax.inject.Inject
import scala.concurrent.ExecutionContext

class RegistrationInProgressController @Inject() (
  val controllerComponents: MessagesControllerComponents,
  identify:                 IdentifierAction,
  viewHomepage:             RegistrationInProgressView,
  subscriptionService:      SubscriptionService
)(using appConfig: FrontendAppConfig, ec: ExecutionContext)
    extends FrontendBaseController
    with I18nSupport
    with Logging {

  def onPageLoad(plrReference: String): Action[AnyContent] = identify.async { request =>
    given Request[AnyContent] = request
    val view: String => Html =
      (ref: String) => viewHomepage(ref)

    subscriptionService
      .maybeReadSubscription(plrReference)
      .map {
        case Some(_) =>
          Redirect(controllers.routes.HomepageController.onPageLoad())
        case None =>
          Ok(view(plrReference))
      }
      .recover {
        case UnprocessableEntityError =>
          Ok(view(plrReference))
        case e: Throwable =>
          logger.warn(s"Registration in progress page failed with error: ${e.getMessage}")
          Redirect(routes.JourneyRecoveryController.onPageLoad())
      }
  }
}
