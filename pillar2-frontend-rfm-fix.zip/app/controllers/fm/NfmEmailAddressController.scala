/*
 * Copyright 2024 HM Revenue & Customs
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package controllers.fm

import config.FrontendAppConfig
import connectors.UserAnswersConnectors
import controllers.actions.{DataRequiredAction, DataRetrievalAction, IdentifierAction}
import forms.NfmEmailAddressFormProvider
import models.Mode
import navigation.NominatedFilingMemberNavigator
import pages.{FmContactEmailPage, FmContactNamePage}
import play.api.i18n.I18nSupport
import play.api.libs.json.Json
import play.api.mvc.*
import uk.gov.hmrc.play.bootstrap.frontend.controller.FrontendBaseController
import views.html.fmview.NfmEmailAddressView

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class NfmEmailAddressController @Inject() (
  val userAnswersConnectors: UserAnswersConnectors,
  identify:                  IdentifierAction,
  getData:                   DataRetrievalAction,
  requireData:               DataRequiredAction,
  navigator:                 NominatedFilingMemberNavigator,
  formProvider:              NfmEmailAddressFormProvider,
  val controllerComponents:  MessagesControllerComponents,
  view:                      NfmEmailAddressView
)(using ec: ExecutionContext, appConfig: FrontendAppConfig)
    extends FrontendBaseController
    with I18nSupport {

  def onPageLoad(mode: Mode): Action[AnyContent] = (identify andThen getData andThen requireData) { request =>
    given Request[AnyContent] = request
    request.userAnswers
      .get(FmContactNamePage)
      .map { name =>
        val form         = formProvider(name)
        val preparedForm = request.userAnswers.get(FmContactEmailPage) match {
          case Some(value) => form.fill(value)
          case None        => form
        }
        Ok(view(preparedForm, mode, name))
      }
      .getOrElse(Redirect(controllers.routes.JourneyRecoveryController.onPageLoad()))
  }

  def onSubmit(mode: Mode): Action[AnyContent] = (identify andThen getData andThen requireData).async { request =>
    given Request[AnyContent] = request
    request.userAnswers
      .get(FmContactNamePage)
      .map { userName =>
        formProvider(userName)
          .bindFromRequest()
          .fold(
            formWithErrors => Future.successful(BadRequest(view(formWithErrors, mode, userName))),
            value =>
              for {
                updatedAnswers <- Future.fromTry(request.userAnswers.set(FmContactEmailPage, value))
                _              <- userAnswersConnectors.save(updatedAnswers.id, Json.toJson(updatedAnswers.data))
              } yield Redirect(navigator.nextPage(FmContactEmailPage, mode, updatedAnswers))
          )
      }
      .getOrElse(Future.successful(Redirect(controllers.routes.JourneyRecoveryController.onPageLoad())))
  }
}
