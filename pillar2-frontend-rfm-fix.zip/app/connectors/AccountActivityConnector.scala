/*
 * Copyright 2024 HM Revenue & Customs
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package connectors

import config.FrontendAppConfig
import models.*
import play.api.Logging
import play.api.http.Status.{NOT_FOUND, OK, UNPROCESSABLE_ENTITY}
import play.api.libs.json.Json
import uk.gov.hmrc.http.HttpReads.Implicits.readRaw
import uk.gov.hmrc.http.client.HttpClientV2
import uk.gov.hmrc.http.{HeaderCarrier, HttpResponse, StringContextOps}

import java.time.LocalDate
import java.time.LocalDateTime
import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class AccountActivityConnector @Inject() (val config: FrontendAppConfig, val http: HttpClientV2, ec: ExecutionContext) extends Logging {
  given ExecutionContext = ec

  private val noDataFoundCode = "\"code\":\"014\""

  def retrieveAccountActivity(plrReference: String, dateFrom: LocalDate, dateTo: LocalDate)(using
    hc: HeaderCarrier
  ): Future[AccountActivityResponse] =
    http
      .get(url"${config.pillar2BaseUrl}/report-pillar2-top-up-taxes/account-activity?fromDate=${dateFrom.toString}&toDate=${dateTo.toString}")
      .setHeader("X-Pillar2-Id" -> plrReference)
      .execute[HttpResponse]
      .flatMap {
        case response if response.status == OK        => Future successful Json.parse(response.body).as[AccountActivityResponse]
        case response if response.status == NOT_FOUND =>
          logger.warn(s"Account activity not found for $plrReference")
          Future failed NoResultFound
        case response if response.status == UNPROCESSABLE_ENTITY && response.body.replaceAll("\\s", "").contains(noDataFoundCode) =>
          logger.warn(s"Account activity no data found (422/014) for $plrReference")
          Future successful AccountActivityResponse(LocalDateTime.now(), Seq.empty)
        case e @ _ =>
          logger.error(s"Account activity error for $plrReference - status=${e.status} - error=${e.body}")
          Future failed UnexpectedResponse
      }

}
