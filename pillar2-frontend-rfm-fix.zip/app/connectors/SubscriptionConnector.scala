/*
 * Copyright 2024 HM Revenue & Customs
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package connectors

import config.FrontendAppConfig
import connectors.SubscriptionConnector.constructUrl
import models.*
import models.subscription.*
import org.apache.pekko.Done
import play.api.Logging
import play.api.http.Status.*
import play.api.libs.json.*
import play.api.libs.ws.JsonBodyWritables.writeableOf_JsValue
import uk.gov.hmrc.http.*
import uk.gov.hmrc.http.HttpErrorFunctions.is2xx
import uk.gov.hmrc.http.HttpReads.Implicits.readRaw
import uk.gov.hmrc.http.client.HttpClientV2
import utils.FutureConverter.toFuture

import javax.inject.{Inject, Singleton}
import scala.concurrent.{ExecutionContext, Future}

@Singleton
class SubscriptionConnector @Inject() (val config: FrontendAppConfig, val http: HttpClientV2)(using ec: ExecutionContext) extends Logging {
  private val subscriptionUrl: String = s"${config.pillar2BaseUrl}/report-pillar2-top-up-taxes/subscription/create-subscription"

  def subscribe(subscriptionRequestParameters: SubscriptionRequestParameters)(using hc: HeaderCarrier): Future[String] =
    http
      .post(url"$subscriptionUrl")
      .withBody(Json.toJson(subscriptionRequestParameters))
      .execute[HttpResponse]
      .flatMap {
        case response if is2xx(response.status) =>
          logger.info(s" Subscription request is successful with status ${response.status} ")
          response.json.as[SuccessResponse].success.plrReference.toFuture
        case conflictResponse if conflictResponse.status.equals(CONFLICT)                                   => Future.failed(DuplicateSubmissionError)
        case unprocessableEntityResponse if unprocessableEntityResponse.status.equals(UNPROCESSABLE_ENTITY) => Future.failed(UnprocessableEntityError)
        case errorResponse                                                                                  =>
          logger.debug(
            s"[Subscription failed with regSafeId ${subscriptionRequestParameters.regSafeId} " +
              s"and fmSafeId ${subscriptionRequestParameters.fmSafeId}"
          )
          logger.warn(s"Subscription call failed with status ${errorResponse.status}")

          Future.failed(InternalIssueError)
      }

  def cacheSubscription(
    readSubscriptionParameter: ReadSubscriptionRequestParameters
  )(using hc: HeaderCarrier, ec: ExecutionContext): Future[SubscriptionDataV1] = {
    val subscriptionUrl = constructUrl(readSubscriptionParameter, config)
    http
      .get(url"$subscriptionUrl")
      .execute[HttpResponse]
      .flatMap {
        case response if response.status == OK =>
          Future.successful(Json.parse(response.body).as[SubscriptionDataV1])
        case e =>
          logger.warn(s"Connection issue when calling cache subscription with status: ${e.status}")
          if RetryableGatewayError.retryableStatuses(e.status) then Future.failed(RetryableGatewayError)
          else Future.failed(InternalIssueError)
      }
  }

  def readSubscription(
    plrReference: String
  )(using hc: HeaderCarrier, ec: ExecutionContext): Future[Option[SubscriptionDataV1]] = {
    val subscriptionUrl = s"${config.pillar2BaseUrl}/report-pillar2-top-up-taxes/subscription/read-subscription/$plrReference"

    http
      .get(url"$subscriptionUrl")
      .execute[HttpResponse]
      .flatMap {
        case response if response.status == 200 =>
          Future.successful(Some(Json.parse(response.body).as[SubscriptionSuccess].success))
        case response if response.status == UNPROCESSABLE_ENTITY =>
          Future.failed(UnprocessableEntityError)
        case notFoundResponse if notFoundResponse.status == 404 => Future.successful(None)
        case e                                                  =>
          logger.warn(s"Connection issue when calling read subscription with status: ${e.status}")
          if RetryableGatewayError.retryableStatuses(e.status) then Future.failed(RetryableGatewayError)
          else Future.failed(InternalIssueError)
      }
  }

  /** Read and cache Subscription V2: returns multiple accounting periods with canAmend flags, caches the result. */
  def readAndCacheSubscriptionV2(
    userId:       String,
    plrReference: String
  )(using hc: HeaderCarrier, ec: ExecutionContext): Future[SubscriptionDataV2] = {
    val url = s"${config.pillar2BaseUrl}/report-pillar2-top-up-taxes/subscription/v2/read-subscription/$userId/$plrReference"
    http
      .get(url"$url")
      .execute[HttpResponse]
      .flatMap {
        case response if response.status == OK =>
          Future.successful(Json.parse(response.body).as[SubscriptionDataV2])
        case response if response.status == UNPROCESSABLE_ENTITY =>
          Future.failed(UnprocessableEntityError)
        case notFoundResponse if notFoundResponse.status == NOT_FOUND =>
          Future.failed(NoResultFound)
        case e =>
          logger.warn(s"Connection issue when calling read subscription v2 with status: ${e.status}")
          if RetryableGatewayError.retryableStatuses(e.status) then Future.failed(RetryableGatewayError)
          else Future.failed(InternalIssueError)
      }
  }

  /** Read Subscription V2 (no cache). Uses the v2 endpoint that returns multiple accounting periods. */
  def readSubscriptionV2(
    plrReference: String
  )(using hc: HeaderCarrier, ec: ExecutionContext): Future[Option[SubscriptionDataV2]] = {
    val subscriptionUrl = s"${config.pillar2BaseUrl}/report-pillar2-top-up-taxes/subscription/v2/read-subscription/$plrReference"
    http
      .get(url"$subscriptionUrl")
      .execute[HttpResponse]
      .flatMap {
        case response if response.status == OK =>
          Future.successful(Some(Json.parse(response.body).as[SubscriptionSuccessV2].success))
        case response if response.status == UNPROCESSABLE_ENTITY =>
          Future.failed(UnprocessableEntityError)
        case notFoundResponse if notFoundResponse.status == NOT_FOUND => Future.successful(None)
        case e                                                        =>
          logger.warn(s"Connection issue when calling read subscription v2 with status: ${e.status}")
          if RetryableGatewayError.retryableStatuses(e.status) then Future.failed(RetryableGatewayError)
          else Future.failed(InternalIssueError)
      }
  }

  def getSubscriptionCache(
    userId: String
  )(using hc: HeaderCarrier, ec: ExecutionContext): Future[Option[SubscriptionLocalData]] =
    http
      .get(url"${config.pillar2BaseUrl}/report-pillar2-top-up-taxes/user-cache/read-subscription/$userId")
      .execute[HttpResponse]
      .map {
        case response if response.status == 200 =>
          Json.parse(response.body).validate[SubscriptionLocalData] match {
            case JsSuccess(data, _) => Some(data)
            case JsError(errors)    =>
              logger.warn(s"Read subscription cache parse error for user $userId: $errors")
              None
          }
        case e =>
          logger.warn(s"Connection issue when calling read subscription with status: ${e.status} ${e.body}")
          None
      }

  def save(userId: String, subscriptionLocalData: JsValue)(using
    hc: HeaderCarrier
  ): Future[JsValue] =
    http
      .post(url"${config.pillar2BaseUrl}/report-pillar2-top-up-taxes/user-cache/read-subscription/$userId")
      .withBody(Json.toJson(subscriptionLocalData))
      .execute[HttpResponse]
      .map { response =>
        response.status match {
          case OK => subscriptionLocalData
          case _  => throw new HttpException(response.body, response.status)
        }
      }

  def amendSubscription(userId: String, amendData: AmendSubscription)(using hc: HeaderCarrier): Future[Done] =
    http
      .put(url"${config.pillar2BaseUrl}/report-pillar2-top-up-taxes/subscription/amend-subscription/$userId")
      .withBody(Json.toJson(amendData))
      .execute[HttpResponse]
      .flatMap { response =>
        response.status match {
          case OK =>
            logger.info(s"amendSubscription - success")
            Done.toFuture
          case error =>
            logger.warn(s"amendSubscription - $error")
            Future.failed(UnexpectedResponse)
        }
      }

  def amendSubscriptionV2(userId: String, amendData: AmendSubscriptionV2)(using hc: HeaderCarrier): Future[Done] = {
    val amendUrl = s"${config.pillar2BaseUrl}/report-pillar2-top-up-taxes/subscription/v2/amend-subscription/$userId"
    http
      .put(url"$amendUrl")
      .withBody(Json.toJson(amendData))
      .execute[HttpResponse]
      .flatMap { response =>
        response.status match {
          case OK =>
            logger.info(s"amendSubscriptionV2 - success")
            Done.toFuture
          case error =>
            logger.warn(s"amendSubscriptionV2 - $error")
            Future.failed(UnexpectedResponse)
        }
      }
  }
}

object SubscriptionConnector {
  private def constructUrl(readSubscriptionParameter: ReadSubscriptionRequestParameters, config: FrontendAppConfig): String =
    s"${config.pillar2BaseUrl}/report-pillar2-top-up-taxes/subscription/read-subscription/${readSubscriptionParameter.id}/${readSubscriptionParameter.plrReference}"

}
